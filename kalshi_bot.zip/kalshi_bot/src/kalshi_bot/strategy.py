from __future__ import annotations

from .config import Settings
from .models import Market, Signal


class MeanReversionMaker:
    """Simple first-pass strategy.

    Looks for open markets with enough liquidity where the quoted spread is acceptable,
    and last trade has drifted away from the book midpoint.
    """

    def __init__(self, settings: Settings):
        self.settings = settings

    def evaluate(self, market: Market) -> Signal | None:
        if self.settings.category_filter and market.category not in self.settings.category_filter:
            return None
        if market.volume_24h < self.settings.min_daily_volume:
            return None
        if market.yes_bid <= 0 or market.yes_ask <= 0:
            return None

        spread = max(0, market.yes_ask - market.yes_bid)
        if spread > 12:
            return None

        midpoint = (market.yes_bid + market.yes_ask) / 2
        drift = int(round(midpoint - market.last_price))
        if abs(drift) < self.settings.edge_threshold_cents:
            return None

        side = "yes" if drift > 0 else "no"
        price = market.yes_bid + 1 if side == "yes" else market.no_bid + 1
        score = abs(drift) * 1.25 + max(0, 8 - spread) + min(10, market.volume_24h / 250)
        reason = f"midpoint={midpoint:.1f}, last={market.last_price}, drift={drift}, spread={spread}, vol24h={market.volume_24h:.0f}"
        return Signal(
            ticker=market.ticker,
            title=market.title,
            side=side,
            price=int(price),
            edge_cents=abs(drift),
            spread_cents=spread,
            score=score,
            reason=reason,
        )
